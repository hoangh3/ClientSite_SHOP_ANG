require('../position/index-nocss.js');
require('./dropdown');

var MODULE_NAME = 'ui.bootstrap.module.dropdown';

angular.module(MODULE_NAME, ['ui.bootstrap.dropdown']);

module.exports = MODULE_NAME;
