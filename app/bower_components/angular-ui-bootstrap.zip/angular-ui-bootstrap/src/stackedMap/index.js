require('./stackedMap');

var MODULE_NAME = 'ui.bootstrap.module.stackedMap';

angular.module(MODULE_NAME, ['ui.bootstrap.stackedMap']);

module.exports = MODULE_NAME;
